const AWS = require('aws-sdk');
const ES = require('./elasticsearch');

const reko = new AWS.Rekognition({
    apiVersion: '2016-06-27'
});

// Elasticsearch에 Index가 없다면 생성.
ES.indexExists().then((exists) => {
    if(!exists) {
        ES.initIndex();
        ES.initMapping();
        return;
    }
}).catch((error) => {console.error(error)});

// ES에 넣을 데이터 생성 및 데이터 전송
function indexNewDocument(imgTitle, imgS3Location, resultDictionary) {
    let resultNestedObj = [];

    for(const key in resultDictionary) {
        resultNestedObj.push({"tag":key, "score":resultDictionary[key]});
    }

    return ES.addImages(imgTitle, imgS3Location, resultNestedObj);
}

exports.handler = async (event) => {
    try{
        const body = JSON.parse(event["Records"][0]["body"]);
        const filenameKey = body["Records"][0]["s3"]["object"]["key"];
        
        const rekoParams = {
                Image: {
                    S3Object: {
                        // S3 버킷 이름을 입력하세요
                        Bucket: "<S3 Bucket name>",
                        Name: filenameKey
                    }
                },
            MaxLabels: 123,
            MinConfidence: 70
        };

        let resultDictionary = {};
        
        const labels = await reko.detectLabels(rekoParams).promise();            
            labels['Labels'].forEach((label) => {
                resultDictionary[label['Name']] = label['Confidence'];
            });        

        /*
        * ex) `https://s3.ap-northeast-2.amazonaws.com/seonny-bucket/${filenameKey}`
        * 주의 : 서울리전 (ap-northeast-2)를 본인의 리전에 맞게 수정해주세요
        */
        const s3_location = `https://s3.ap-northeast-2.amazonaws.com/<S3 Bucket name>/${filenameKey}`;
        
        await indexNewDocument(filenameKey, s3_location, resultDictionary);      
        
        const response = {
            statusCode: 200,
            body: JSON.stringify('Success'),
        };

        return response;
    }catch(error){
        console.error(error);

        const response = {
            statusCode: 400,
            body: JSON.stringify('Fail'),
        };

        return response;
    }    
};